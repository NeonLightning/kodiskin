# Terminal 80

Terminal 80 is a dark Kodi skin with phosphor-green text, monospace fonts, and amber focus labels. Media Info 2 is the default video library view.

![Terminal 80 Media Info 2 view with a sample movie library](extras/viewthumbs/57.jpg)

## Upstream attribution

Original skin: **Eminence 2.0** by **jurialmunkey**.
Upstream repository: https://github.com/jurialmunkey/skin.eminence.2

The upstream work is licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported (CC BY-NC-SA 3.0)**. This derivative is distributed under the same license. See `LICENSE.txt` for the upstream license notice and the upstream repository for full attribution and source history.

Terminal 80 visual assets and modifications are provided as a non-commercial derivative. DejaVu Sans Mono font files are included under their respective upstream license in `fonts/DEJAVU-FONTS-LICENSE.txt`.
